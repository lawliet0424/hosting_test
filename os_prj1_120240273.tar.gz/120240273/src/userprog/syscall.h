#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

//? Is it int? Not a tid_t?
typedef int pid_t;

void syscall_init (void);

void halt (void);
void exit (int status);
pid_t exec (const char *file);
int wait (pid_t pid);
int read (int fd, void *buffer, unsigned length);
int write (int fd, const void *buffer, unsigned length);
void checkUserProvidedPointer (void *vaddr);

#endif /* userprog/syscall.h */
