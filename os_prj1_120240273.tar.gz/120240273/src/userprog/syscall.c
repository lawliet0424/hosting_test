#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "userprog/pagedir.h"
#include "userprog/process.h"
#include "devices/input.h"
#include "lib/kernel/console.h"
#include "devices/shutdown.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f)
{
    //printf ("system call!\n");

    int syscallNum = *(int *) f -> esp;

    switch (syscallNum) {
        case SYS_HALT:
            halt();
            break;
        case SYS_EXIT:
            checkUserProvidedPointer(f -> esp + 4);
            exit(*(int *)(f -> esp + 4));
            break;
        case SYS_EXEC:
            checkUserProvidedPointer(f -> esp + 4);
            f -> eax = exec(*(const char**)(f -> esp + 4));
            break;
        case SYS_WAIT:
            checkUserProvidedPointer(f -> esp + 4);
            f -> eax = wait(*(pid_t *)(f -> esp + 4));
            break;
        case SYS_READ:
            checkUserProvidedPointer(f -> esp + 4);
            checkUserProvidedPointer(f -> esp + 8);
            checkUserProvidedPointer(f -> esp + 12);
            f -> eax = read(*(int *)(f -> esp + 4), *(void **)(f -> esp + 8), *(unsigned *)(f -> esp + 12));
            break;
        case SYS_WRITE:
            checkUserProvidedPointer(f -> esp + 4);
            checkUserProvidedPointer(f -> esp + 8);
            checkUserProvidedPointer(f -> esp + 12);
            f -> eax = write(*(int *)(f -> esp + 4), *(const void **)(f -> esp + 8), *(unsigned *)(f -> esp + 12));
            break;
    }
}

void halt (void) {
    shutdown_power_off();
}

void exit (int status) {
    const char *currentThreadName = thread_name();

    printf ("%s: exit(%d)\n", currentThreadName, status);

    thread_exit();
}

pid_t exec (const char *file) {
    return process_execute(file);
}

int wait (pid_t pid) {
    return process_wait(pid);
}

int read (int fd, void *buffer, unsigned length) {
    if(fd != 0) {
        return - 1;
    }

    int reading;
    for(reading = 0; reading < length; reading++) {
        int ch = input_getc();

        if(ch == '\0') {
            return -1;
        }

        ((char *)buffer)[reading] = ch;
    }

    return reading;
}

int write (int fd, const void *buffer, unsigned length) {
    if(fd != 1) {
        return -1;
    }

    putbuf(buffer, length);
    return length;
}

void checkUserProvidedPointer (void *vaddr) {
    if(vaddr == NULL) {
        exit(-1);
    }

    if(is_kernel_vaddr(vaddr)) {
        exit(-1);
    }

    if(!is_user_vaddr(vaddr)) {
        exit(-1);
    }

    if(pagedir_get_page(thread_current()->pagedir, vaddr) == NULL) {
        exit(-1);
    }

}
